package ashutosh.foodie_guide.attendance_application.utils;

public class Utils{
    public static final String ip="http://172.22.47.160/";
    public static final String location="nfc/";
    public static final String COURSE_LIST_URL="http://172.22.47.160/nfc/getCourseList.php";

    public static final String REGISTER_URL = Utils.ip+Utils.location+"register.php";

    public static final String KEY_ROLL_NO = "rollNo";
    public static final String KEY_TAG_KEY = "tagKey";

}