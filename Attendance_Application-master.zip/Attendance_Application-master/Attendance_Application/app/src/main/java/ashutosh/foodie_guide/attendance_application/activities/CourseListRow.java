package ashutosh.foodie_guide.attendance_application.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ashutosh.foodie_guide.attendance_application.R;

public class CourseListRow extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_list_row);
    }
}
