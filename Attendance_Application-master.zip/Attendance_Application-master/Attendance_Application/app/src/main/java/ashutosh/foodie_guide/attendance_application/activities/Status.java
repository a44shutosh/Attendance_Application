package ashutosh.foodie_guide.attendance_application.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ashutosh.foodie_guide.attendance_application.R;

public class Status extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
    }
}
