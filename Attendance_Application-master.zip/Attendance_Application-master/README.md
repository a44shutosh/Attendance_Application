# Attendance_Application
An android app that uses NFC hardware to register and monitor attendance
